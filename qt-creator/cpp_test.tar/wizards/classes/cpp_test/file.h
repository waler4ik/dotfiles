%{Cpp:LicenseTemplate}\
#ifndef %{GUARD}
#define %{GUARD}

#include <cppunit/TestFixture.h>
#include <cppunit/extensions/HelperMacros.h>

namespace %{Namespace}
{
class %{CN} : public CppUnit::TestCase
{
    CPPUNIT_TEST_SUITE(%{CN});
    CPPUNIT_TEST(testSomeThing);
    CPPUNIT_TEST_SUITE_END();
public:
    %{CN}();
    virtual ~%{CN}();
    void setUp();
    void tearDown();

    void testSomeThing();
private:
};
}
#endif // %{GUARD}\
