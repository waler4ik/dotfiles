%{Cpp:LicenseTemplate}\
#include "%{HdrFileName}"

namespace %{Namespace}
{
%{CN}::%{CN}()
{

}

%{CN}::~%{CN}()
{

}

void %{CN}::setUp()
{
  
}

void %{CN}::tearDown()
{

}

void %{CN}::testSomeThing()
{
    //use a lot of CPPUNIT_ASSERT_EQUAL(exptected, actual);
}
}
